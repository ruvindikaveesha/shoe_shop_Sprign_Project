package com.codeventlk.helloshoemanagementsystem.Enum;

public enum Level {
    GOLD,SILVER,BRONZE,NEW
}
