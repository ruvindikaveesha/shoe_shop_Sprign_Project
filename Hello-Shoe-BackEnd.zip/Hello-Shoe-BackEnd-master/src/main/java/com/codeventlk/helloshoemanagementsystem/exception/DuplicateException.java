package com.codeventlk.helloshoemanagementsystem.exception;

public class DuplicateException extends RuntimeException{
    public DuplicateException(String message) {
        super(message);
    }
}
