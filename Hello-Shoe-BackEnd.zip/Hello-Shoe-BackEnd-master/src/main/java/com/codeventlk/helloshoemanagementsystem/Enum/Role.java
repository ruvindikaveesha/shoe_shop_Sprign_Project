package com.codeventlk.helloshoemanagementsystem.Enum;

public enum Role {
    ADMIN,USER
}
