package com.codeventlk.helloshoemanagementsystem.repository;

public interface SaleServiceDao {
}
