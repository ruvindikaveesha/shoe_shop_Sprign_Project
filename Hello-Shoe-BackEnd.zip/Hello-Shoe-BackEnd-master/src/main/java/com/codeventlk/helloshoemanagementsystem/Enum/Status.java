package com.codeventlk.helloshoemanagementsystem.Enum;

public enum Status {
    LOW,AVAILABLE,NOTAVAILABLE
}
