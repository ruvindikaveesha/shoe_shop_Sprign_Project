package com.codeventlk.helloshoemanagementsystem.controller;

public class Sale {
}
