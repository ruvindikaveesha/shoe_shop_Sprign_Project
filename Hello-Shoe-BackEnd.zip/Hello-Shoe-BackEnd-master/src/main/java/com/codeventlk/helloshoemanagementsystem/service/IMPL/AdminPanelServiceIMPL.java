package com.codeventlk.helloshoemanagementsystem.service.IMPL;

public class AdminPanelServiceIMPL {
}
