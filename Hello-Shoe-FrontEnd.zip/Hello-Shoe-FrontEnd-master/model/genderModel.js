export class GenderModel{
    constructor(genderCode,genderDesc) {
        this.genderCode = genderCode;
        this.genderDesc = genderDesc;
    }
}