package com.codeventlk.helloshoemanagementsystem.Enum;

public enum PaymentMethod {
    CASH,CARD
}
