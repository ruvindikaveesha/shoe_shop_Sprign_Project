export class OccasionModel{
    constructor(occasionCode,occasionDesc) {
        this.occasionCode = occasionCode;
        this.occasionDesc = occasionDesc;
    }
}