package com.codeventlk.helloshoemanagementsystem.dto;

public interface SuperDTO {
}
