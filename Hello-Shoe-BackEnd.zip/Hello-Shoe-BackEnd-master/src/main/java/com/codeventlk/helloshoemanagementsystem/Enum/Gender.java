package com.codeventlk.helloshoemanagementsystem.Enum;

public enum Gender {
    MALE,FEMALE
}
