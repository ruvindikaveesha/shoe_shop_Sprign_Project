export class BranchModel {
    constructor(branchName,productCode) {
        this.branchName=branchName;
        this.productCode=productCode;
    }

}