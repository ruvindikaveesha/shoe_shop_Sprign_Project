package com.codeventlk.helloshoemanagementsystem.service;

public interface AdminPanelService {
}
