package com.codeventlk.helloshoemanagementsystem.Enum;

public enum Category {
    INTERNATIONAL,LOCAL
}
