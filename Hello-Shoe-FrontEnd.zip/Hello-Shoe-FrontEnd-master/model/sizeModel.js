export class SizeModel {
    constructor(sizeCode, sizeDesc) {
        this.sizeCode = sizeCode;
        this.sizeDesc = sizeDesc;
    }
}
