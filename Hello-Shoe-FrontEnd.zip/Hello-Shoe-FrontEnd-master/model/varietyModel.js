export class VarietyModel{
    constructor(varietyCode,varietyDesc) {
        this.varietyCode = varietyCode;
        this.varietyDesc = varietyDesc;
    }
}