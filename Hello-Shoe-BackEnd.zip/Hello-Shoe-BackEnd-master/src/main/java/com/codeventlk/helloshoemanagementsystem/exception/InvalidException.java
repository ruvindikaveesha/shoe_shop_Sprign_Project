package com.codeventlk.helloshoemanagementsystem.exception;

public class InvalidException extends RuntimeException{
    public InvalidException(String message) {
        super(message);
    }
}
